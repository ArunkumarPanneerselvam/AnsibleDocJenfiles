#!/usr/bin/python

def sayHello():
   print ( 'Hello Python!' )
   print ( 'This will not give syntax error' )

def main():
    sayHello()

main()
