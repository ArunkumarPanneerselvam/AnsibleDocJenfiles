You can refer some of Youtube videos here

https://www.youtube.com/user/BulletJegan/videos

Subscribe if you wish to be notified

My blog
http://www.tektutor.org/blog

Write me for any queries @ jegan@tektutor.org
