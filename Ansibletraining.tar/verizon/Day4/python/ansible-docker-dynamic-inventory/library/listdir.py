#!/usr/bin/python

from ansible.module_utils.basic import *;
import subprocess

class List:
   def listdirectory(self.directory):
       if (directory == None ):
            return subprocess.check_output ("ls -l ") + directory).strip()
       else: 
            return 

def main():
   module = AnsibleModule ( argument_spec = dict () )
   hello = Hello()
   result = { "Result": hello.sayHello() }
   module.exit_json ( changed=False, meta=result )

main()
